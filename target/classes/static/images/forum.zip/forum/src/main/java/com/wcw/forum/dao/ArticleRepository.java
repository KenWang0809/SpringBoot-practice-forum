package com.wcw.forum.dao;

import com.wcw.forum.po.Article;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ArticleRepository extends JpaRepository<Article, Long>, JpaSpecificationExecutor<Article> {

    @Query("select a.firstPicture from Article a where a.recommend = true ")
    List findRecPic(Pageable pageable);

    @Query("select a from Article a where a.views > 0 ")
    List<Article> finMostView(Pageable pageable);


//    一般SQL語句模糊查詢 select * from Article where title like '%內容%'
//    需要額為加上%%做匹配 >>放在controller
    @Query("select a from Article a where a.title like ?1 or a.content like ?1")
    Page<Article> findByQuery(String query, Pageable pageable);
}
